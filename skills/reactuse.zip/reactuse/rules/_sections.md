# Sections

This file defines all sections, their ordering, impact levels, and descriptions.
The section ID (in parentheses) is the filename prefix used to group rules.

---

## 1. Helpers

**Impact:** AUTO  
**Description:** Helper factories for contexts, stores, event emitters, WebMCP registries, equality checks, target utilities, class names, and destructurable values.

## 2. Elements

**Impact:** AUTO  
**Description:** Hooks for interacting with DOM elements, focus, layout, collapse transitions, and element-based behaviors.

## 3. Async

**Impact:** AUTO  
**Description:** Hooks for handling asynchronous operations and async state.

## 4. Lifecycle

**Impact:** AUTO  
**Description:** Hooks for managing effects, configurable dependency comparison, mount/unmount, and lifecycle side effects.

## 5. Browser

**Impact:** AUTO  
**Description:** Hooks for browser APIs, WebMCP tools, media, storage, navigation, and environment signals.

## 6. Utilities

**Impact:** AUTO  
**Description:** General-purpose utility hooks for callbacks, refs, collections, and helpers.

## 7. State

**Impact:** AUTO  
**Description:** Hooks for managing local and shared state, persistence, and state helpers to keep UI logic concise and predictable.

## 8. User

**Impact:** AUTO  
**Description:** Hooks for user preferences, input behaviors, and interaction patterns.

## 9. Sensors

**Impact:** AUTO  
**Description:** Hooks for device sensors, observers, and visibility/measurement signals.

## 10. Time

**Impact:** AUTO  
**Description:** Hooks for timing, scheduling, debounce/throttle, and animation frames.

## 11. Debug

**Impact:** AUTO  
**Description:** Hooks for logging, render diagnostics, and debugging helpers.

## Blocked Upstream Categories

Reactuse exports a `Humor` category in recent releases, currently `useFul`, `useLess`, and `useOnce`. Keep it blocked for this skill: do not add those rules or recommend those hooks unless the user explicitly asks to document unsupported upstream exports. Upstream marks them as jokes or non-production utilities.
